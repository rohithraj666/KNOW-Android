# KNOW Android App

KNOW is a separate offline Android app for storing titled notes with long descriptions.

- App name: KNOW
- Package/application ID: `com.example.know` (different from Briefcase)
- Black theme and slightly larger text
- Title and Description fields only
- No PIN or fingerprint lock
- Long, multiline descriptions
- Selectable text for Android copy actions
- JSON import/export compatible with legacy `word`/`definition` and current `title`/`description` fields
- Delete with confirmation
- Local storage; no account required

Build with Java 17 installed and Gradle 8.9: `gradle assembleDebug`
